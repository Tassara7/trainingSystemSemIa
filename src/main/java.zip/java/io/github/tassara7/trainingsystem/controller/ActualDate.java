package io.github.tassara7.trainingsystem.controller;

import java.time.LocalDate;

public interface ActualDate {
    void setDate(LocalDate date);
}
