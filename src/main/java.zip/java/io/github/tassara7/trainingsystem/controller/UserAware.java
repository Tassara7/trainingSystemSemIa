package io.github.tassara7.trainingsystem.controller;

import io.github.tassara7.trainingsystem.model.User;

public interface UserAware {
    void setUser(User user);
}
