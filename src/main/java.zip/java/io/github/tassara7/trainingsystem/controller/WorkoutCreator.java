package io.github.tassara7.trainingsystem.controller;

import io.github.tassara7.trainingsystem.model.Workout;

public interface WorkoutCreator {
    void setWorkout(Workout workout);
}
