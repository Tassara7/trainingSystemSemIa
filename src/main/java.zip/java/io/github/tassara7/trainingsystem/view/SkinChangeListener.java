package io.github.tassara7.trainingsystem.view;

import javafx.scene.control.Skin;

public interface SkinChangeListener {
    void onSkinChanged();
}
