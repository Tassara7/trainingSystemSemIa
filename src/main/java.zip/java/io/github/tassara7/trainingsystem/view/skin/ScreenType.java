package io.github.tassara7.trainingsystem.view.skin;

public enum ScreenType {
    MONTH,
    YEAR,
    NEW_WORKOUT,
    CONFIG
}
