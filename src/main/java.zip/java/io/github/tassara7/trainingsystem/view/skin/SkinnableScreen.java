package io.github.tassara7.trainingsystem.view.skin;

public interface SkinnableScreen {
    ScreenType getScreenType();
}
